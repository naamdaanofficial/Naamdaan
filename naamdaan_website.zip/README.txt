
Naam Daan — Premium Gold Theme Static Website
---------------------------------------------
Files included:
- index.html  (main site)
- styles.css  (theme styles)
- script.js   (quote animation + form demo)
- README.txt  (this file)

How to deploy (quick):
1) Create a GitHub repository (naamdaan-website).
2) Upload all files (index.html, styles.css, script.js).
3) Go to Vercel.com -> Login with GitHub -> New Project -> Import repository -> Deploy.
4) Or directly drag-and-drop files to Netlify deploy (https://app.netlify.com/drop).

This is a static site (no backend). Contact form is demo-only. For real messages, integrate with Formspree or Netlify Forms.
